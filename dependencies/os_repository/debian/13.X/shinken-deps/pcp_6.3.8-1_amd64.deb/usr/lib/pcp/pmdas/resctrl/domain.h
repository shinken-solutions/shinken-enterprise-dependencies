/*
 * built from ../../pmns/stdpmid
 */
#define RESCTRL 159
