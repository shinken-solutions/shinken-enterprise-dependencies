/*
 * built from ../../pmns/stdpmid
 */
#define FARM 160
