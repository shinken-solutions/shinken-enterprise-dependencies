die "You need to reinstall DBD::Oracle after installing Data::Dumper
"; 